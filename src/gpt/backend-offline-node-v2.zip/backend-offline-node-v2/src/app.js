import express from 'express';
import dotenv from 'dotenv';
import { pool } from './db.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.get('/', (req, res) => {
  res.json({ ok: true, app: 'backend-offline-node', version: '1.0.1' });
});

app.get('/health', async (req, res) => {
  try {
    const conn = await pool.getConnection();
    const [row] = await conn.query('SELECT NOW() AS db_time');
    conn.release();
    res.json({ ok: true, db_time: row?.db_time ?? null });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

const server = app.listen(PORT, () => {
  console.log(`[OK] backend listening on http://localhost:${PORT}`);
});

// Graceful shutdown
const shutdown = async (signal) => {
  try {
    console.log(`[${signal}] shutting down...`);
    server.close(() => {
      console.log('HTTP server closed');
    });
    await pool.end();
    console.log('DB pool closed');
  } catch (e) {
    console.error('Error on shutdown:', e?.message);
  } finally {
    process.exit(0);
  }
};

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
