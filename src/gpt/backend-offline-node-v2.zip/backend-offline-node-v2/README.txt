Backend Node.js offline (Windows Server) — demo
==============================================

1) Requisitos
   - Node.js ZIP (standalone) copiado en el servidor (p.ej. C:\node\).
   - Este proyecto en el servidor (p.ej. D:\backend-offline-node\).
   - Instalar dependencias desde tu laptop con internet sobre la carpeta compartida.

2) Configuración
   - Renombra `.env.example` a `.env` y valida credenciales.
   - Desde tu laptop (con internet) y dentro de esta carpeta: `npm install`.

3) Probar
   - En el servidor: `node src\app.js`
   - Abre `http://localhost:3000/health` (debe mostrar ok y db_time).

4) Servicio en Windows
   - Opción A (recomendada): NSSM -> `scripts\service-install.bat`
   - Opción B (rápida sin NSSM): `scripts\service-install-sc.bat` (usa `sc create`).

5) (Opcional) Apache reverse proxy: ver `apache-proxy-example.conf`.
