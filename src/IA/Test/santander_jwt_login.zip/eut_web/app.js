const ME   = 'http://180.176.105.244/eut_api_reportes/rutes/me.php';
const AUTH = 'http://180.176.105.244/eut_api_reportes/rutes/auth.php';

async function fetchMe(){
  const res = await fetch(ME, { credentials:'include' });
  if(res.status === 401) { location.href = './login.html'; return; }
  const data = await res.json();
  document.getElementById('hello').textContent = `Hola, ${data.nombre} (${data.user})`;
  document.getElementById('raw').textContent   = JSON.stringify(data, null, 2);
}
fetchMe();

document.getElementById('logoutBtn')?.addEventListener('click', async ()=>{
  await fetch(`${AUTH}?action=logout`, { method:'POST', credentials:'include' });
  location.href = './login.html';
});
