const $ = (s)=>document.querySelector(s);
// Ajusta esta URL si cambias la ruta pública del backend
const API = 'http://180.176.105.244/eut_api_reportes/rutes/auth.php';

async function sha256Hex(txt){
  const enc = new TextEncoder().encode(txt);
  const buf = await crypto.subtle.digest('SHA-256', enc);
  return [...new Uint8Array(buf)].map(b=>b.toString(16).padStart(2,'0')).join('');
}

$('#loginForm')?.addEventListener('submit', async (e)=>{
  e.preventDefault();
  $('#err').textContent = '';
  const r = $('#user').value.trim();
  const pass = $('#pass').value;
  if(!r || !pass){ $('#err').textContent='Usuario y contraseña requeridos'; return; }

  const s = await sha256Hex(pass);

  try{
    const res = await fetch(API, {
      method:'POST',
      credentials:'include',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ r, s })
    });
    const data = await res.json();
    if(res.ok && data.code === "200"){
      location.href = './app.html';
    }else{
      $('#err').textContent = data?.code_msg || 'Credenciales inválidas';
    }
  }catch(err){
    $('#err').textContent = 'No se pudo conectar al servidor';
    console.error(err);
  }
});

$('#clearBtn')?.addEventListener('click', ()=>{
  $('#user').value = ''; $('#pass').value = ''; $('#err').textContent='';
});
