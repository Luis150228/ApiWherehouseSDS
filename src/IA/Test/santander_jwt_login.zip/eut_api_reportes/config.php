<?php
// === JWT & Cookies ===
$JWT_SECRET  = 'CHANGE_ME_TO_A_LONG_RANDOM_SECRET';
$JWT_ISS     = 'eut-api';
$JWT_AUD     = 'eut-web';
$ACCESS_TTL  = 15 * 60;          // 15 min
$REFRESH_TTL = 7  * 24 * 3600;   // 7 días

// Cookies
$COOKIE_DOMAIN   = '';           // p.ej. 'tusitio.com' si aplica
$COOKIE_SECURE   = false;        // true en HTTPS; false solo para pruebas locales
$COOKIE_SAMESITE = 'Lax';        // 'Strict' si todo convive mismo sitio

// CORS (ajusta al origen real del front)
$FRONT_ORIGIN = 'http://180.176.105.244'; // o http://localhost:5500
