<?php
function b64url($data){ return rtrim(strtr(base64_encode($data), '+/', '-_'), '='); }
function b64url_decode($data){ return base64_decode(strtr($data, '-_', '+/')); }

function jwt_encode(array $payload, string $secret){
  $header = ['typ'=>'JWT','alg'=>'HS256'];
  $h = b64url(json_encode($header));
  $p = b64url(json_encode($payload));
  $sig = hash_hmac('sha256', "$h.$p", $secret, true);
  return "$h.$p.".b64url($sig);
}
function jwt_decode(string $jwt, string $secret){
  $parts = explode('.', $jwt);
  if(count($parts) !== 3) return [false,'parts'];
  [$h,$p,$s] = $parts;
  $check = hash_hmac('sha256', "$h.$p", $secret, true);
  if(!hash_equals($check, b64url_decode($s))) return [false,'sig'];
  $payload = json_decode(b64url_decode($p), true);
  return [$payload, null];
}
