<?php
ini_set('max_execution_time', 300);
include_once '../conexion/cnx.php';
require_once '../config.php';
require_once '../lib/jwt.php';
require_once '../rutes/require_auth.php';

class auth extends cnx
{
  public function login($json){
    cors_headers();
    $info = json_decode($json, true) ?: [];
    $user = $info['r'] ?? $info['user'] ?? '';
    $passHash = $info['s'] ?? ''; // cliente manda SHA-256 (hex)

    if(!$user || !$passHash){
      return ['code'=>'400','typeAlert'=>'warning','code_msg'=>'Faltan credenciales'];
    }

    $sql = "CALL userLoggin('$user')";
    $q = parent::getData($sql);
    if(empty($q) || (isset($q[0]['code']) && $q[0]['code']==403)){
      return ['code'=>'401','typeAlert'=>'danger','code_msg'=>'Usuario no encontrado'];
    }

    $row = $q[0];
    $dbHash = $row['Password'] ?? $row['password'] ?? '';
    if(!$dbHash || strtolower($dbHash) !== strtolower($passHash)){
      return ['code'=>'401','typeAlert'=>'danger','code_msg'=>'Credenciales inválidas'];
    }
    if(isset($row['estatus']) && (int)$row['estatus'] !== 1){
      return ['code'=>'403','typeAlert'=>'warning','code_msg'=>'Usuario inactivo'];
    }

    global $JWT_SECRET,$JWT_ISS,$JWT_AUD,$ACCESS_TTL,$REFRESH_TTL;
    $now = time();
    $payload = [
      'sub' => $row['tk'] ?? $row['num_user'] ?? $user,
      'user'=> $row['Usuario'] ?? $row['user'] ?? $user,
      'nombre'=>$row['Nombre'] ?? $row['nombre'] ?? '',
      'nivel'=> (int)($row['nivel'] ?? 0),
      'iss' => $JWT_ISS, 'aud'=>$JWT_AUD,
      'iat' => $now, 'exp' => $now + $ACCESS_TTL
    ];
    $access = jwt_encode($payload, $JWT_SECRET);

    $refreshPayload = ['sub'=>$payload['sub'],'typ'=>'refresh','iat'=>$now,'exp'=>$now+$REFRESH_TTL,'iss'=>$JWT_ISS,'aud'=>$JWT_AUD];
    $refresh = jwt_encode($refreshPayload,$JWT_SECRET);

    set_cookie('access_token',  $access,  $ACCESS_TTL);
    set_cookie('refresh_token', $refresh, $REFRESH_TTL);

    return ['code'=>'200','typeAlert'=>'success','code_msg'=>'Bienvenido','exp'=>$payload['exp'],'user'=>$payload['user'],'nombre'=>$payload['nombre']];
  }

  public function logout(){
    cors_headers();
    clear_cookie('access_token');
    clear_cookie('refresh_token');
    return ['code'=>'200','typeAlert'=>'success','code_msg'=>'Sesión finalizada'];
  }

  public function refresh(){
    cors_headers();
    global $JWT_SECRET,$JWT_ISS,$JWT_AUD,$ACCESS_TTL;
    if(empty($_COOKIE['refresh_token'])) return ['code'=>'401','code_msg'=>'No refresh'];
    [$rp,$err] = jwt_decode($_COOKIE['refresh_token'],$JWT_SECRET);
    if(!$rp || ($rp['typ']??'')!=='refresh' || time() >= ($rp['exp']??0)) return ['code'=>'401','code_msg'=>'Refresh inválido'];

    $now = time();
    $payload = [
      'sub'=>$rp['sub'],'iss'=>$JWT_ISS,'aud'=>$JWT_AUD,
      'iat'=>$now,'exp'=>$now+$ACCESS_TTL
    ];
    $access = jwt_encode($payload,$JWT_SECRET);
    set_cookie('access_token',$access,$ACCESS_TTL);
    return ['code'=>'200','code_msg'=>'ok','exp'=>$payload['exp']];
  }
}
