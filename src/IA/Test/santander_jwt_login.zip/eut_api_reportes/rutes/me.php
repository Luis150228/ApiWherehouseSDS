<?php
require_once __DIR__.'/require_auth.php';
cors_headers();
if ($_SERVER['REQUEST_METHOD']==='OPTIONS'){ http_response_code(204); exit; }

$payload = require_auth();
header('Content-Type: application/json; charset=UTF-8');
echo json_encode([
  'user'   => $payload['user'] ?? $payload['sub'] ?? '',
  'nombre' => $payload['nombre'] ?? '',
  'nivel'  => $payload['nivel'] ?? null,
  'exp'    => $payload['exp'] ?? null
]);
