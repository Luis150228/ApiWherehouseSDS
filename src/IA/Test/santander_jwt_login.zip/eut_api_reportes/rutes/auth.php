<?php
require_once '../classes/auth.class.php';
$_auth = new auth;

cors_headers();
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

header('Content-Type: application/json; charset=UTF-8');

$action = $_GET['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'logout') {
  echo json_encode($_auth->logout()); exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'refresh') {
  echo json_encode($_auth->refresh()); exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $body = file_get_contents('php://input');
  echo json_encode($_auth->login($body)); exit;
}

http_response_code(405);
echo json_encode(['code'=>405,'code_msg'=>'Método no permitido']);
