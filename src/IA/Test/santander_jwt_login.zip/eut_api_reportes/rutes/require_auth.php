<?php
require_once __DIR__.'/../config.php';
require_once __DIR__.'/../lib/jwt.php';

function cors_headers(){
  global $FRONT_ORIGIN;
  header("Access-Control-Allow-Origin: $FRONT_ORIGIN");
  header("Access-Control-Allow-Credentials: true");
  header("Access-Control-Allow-Headers: Content-Type, Authorization");
  header("Access-Control-Allow-Methods: GET, POST, OPTIONS, DELETE");
}

function set_cookie($name,$value,$ttl){
  global $COOKIE_DOMAIN,$COOKIE_SECURE,$COOKIE_SAMESITE;
  setcookie($name, $value, [
    'expires'=> time()+$ttl,
    'path'   => '/',
    'domain' => $COOKIE_DOMAIN ?: '',
    'secure' => $COOKIE_SECURE,
    'httponly'=> true,
    'samesite'=> $COOKIE_SAMESITE
  ]);
}

function clear_cookie($name){
  setcookie($name, '', [
    'expires'=> time()-3600,
    'path'   => '/',
    'secure' => isset($_SERVER['HTTPS']),
    'httponly'=> true,
    'samesite'=> 'Lax'
  ]);
}

function require_auth(){
  global $JWT_SECRET,$JWT_ISS,$JWT_AUD;
  cors_headers();
  if($_SERVER['REQUEST_METHOD']==='OPTIONS'){ http_response_code(204); exit; }

  if(empty($_COOKIE['access_token'])){
    http_response_code(401); header('Content-Type: application/json');
    echo json_encode(['error'=>'no_token']); exit;
  }
  [$payload,$err] = jwt_decode($_COOKIE['access_token'], $JWT_SECRET);
  if(!$payload){ http_response_code(401); header('Content-Type: application/json');
    echo json_encode(['error'=>'bad_token']); exit;
  }
  if(isset($payload['exp']) && time() >= $payload['exp']){
    http_response_code(401); header('Content-Type: application/json');
    echo json_encode(['error'=>'expired']); exit;
  }
  if(($payload['iss']??'') !== $JWT_ISS || ($payload['aud']??'') !== $JWT_AUD){
    http_response_code(401); header('Content-Type: application/json');
    echo json_encode(['error'=>'claims']); exit;
  }
  return $payload;
}
