# Santander JWT Login (vanilla JS + PHP cookies HttpOnly)

## Cómo correr
1) Coloca la carpeta `eut_api_reportes/` en tu servidor PHP donde ya tienes tus clases y SPs.
   - Ajusta `eut_api_reportes/config.php`:
     - `JWT_SECRET` (cadena larga aleatoria)
     - `FRONT_ORIGIN` al origen del front (http://…)
     - `COOKIE_SECURE=true` en producción HTTPS
2) Sirve `eut_web/` con un servidor estático (nginx, apache o live server).
3) Abre `eut_web/login.html` y prueba con un usuario real (el back compara contra el hash SHA-256 que envía el front).
4) Tras login, se setean cookies `access_token` y `refresh_token` HttpOnly/Secure/SameSite.
5) `eut_api_reportes/rutes/me.php` es un endpoint protegido de ejemplo.

## Endpoints
- POST `/rutes/auth.php`            → login (cuerpo: { r: user, s: sha256Hex(password) })
- POST `/rutes/auth.php?action=logout`  → borra cookies
- POST `/rutes/auth.php?action=refresh` → renueva access_token
- GET  `/rutes/me.php`              → devuelve info del usuario (requiere cookie)

